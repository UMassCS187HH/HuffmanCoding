package binaryTree;

public class TreeReceiver {
	private Tree tree;
	private String binary;

	public TreeReceiver(Tree t) {
		tree = t;
	}

	public String decode(String bin2) {
		/*TODO
		 * Given a string in binary, complete the method
		 * that will iterate by each character and use it to
		 * navigate the tree created during the construction
		 * of the TreeReciever Object
		 */
		return null;
	}
}
