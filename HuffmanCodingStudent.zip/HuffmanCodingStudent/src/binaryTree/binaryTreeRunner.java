package binaryTree;

import java.util.HashMap;

public class binaryTreeRunner<T> {
	private String str;
	private Tree t;
	private LLNode<Character> head;
	private HashMap<Character, String> map;
	
	public binaryTreeRunner(String s){
		map = new HashMap<Character, String>();
		str = s.toLowerCase();
		char[] arr = str.toCharArray();
		head = new LLNode<Character>();
		for(char c: arr)
			head.addChar(c);
		head = cleanUp(head);
		head = head.sort(head);
		t = this.buildTree();
		this.createMap(t, new StringBuffer());

	}
	public String getCompression(){
		/*TODO
		 * Create a string that gives the binary search representation
		 * of the original phrase
		 */
		return null;
	}
	public HashMap<Character, String> getMap(){
		//TODO
		return null;
	}
	public Tree getTree(){
		//TODO
		return null;
	}
	/*
	private LLNode<Character> breakDown(String s, LLNode<Character> l){
		LLNode<Character> temp = l;
		LLNode<Character> lln = new LLNode<Character>();
		for(int i = 0; i < str.length(); i++)
			temp.addChar(str.charAt(i));
		return lln;
	}
	*/
	
	private LLNode<Character> cleanUp(LLNode<Character> lln){
		LLNode<Character> pos = lln;
		LLNode<Character> dup = new LLNode<Character>();
		while(true){
			if(!dup.contains(pos.getData()))
				dup.addChar(pos.getData());
			else
				dup.incrementFreq(pos.getData());;
			if(pos.getLink() == null)
				return dup;
			pos = pos.getLink();
		}
	}
	

	
	public LLNode<Character> getHead(){
		return head;
	}
	
	public Tree buildTree(){
		//TODO
		/*
		 * Given a sorted Linked List of Nodes with a character value
		 */
		return null;
	}
	
	public void createMap(Tree tree, StringBuffer binary){
		//TODO 
		/*Complete the Hashmap by creating Keys with the values
		 * as the binary code needed to access the character
		 * on the Tree
		 */
	}
}
