package binaryTree;

public class Tree{
	private int freq;
	
	public Tree(int f){
		freq = f;
	}
	public int getFreq() {
		return freq;
	}
	public void setFreq(int freq) {
		this.freq = freq;
	}

}
